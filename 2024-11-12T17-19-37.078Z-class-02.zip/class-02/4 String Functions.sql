SELECT CHAR_LENGTH("Hello World") AS COL


SELECT LOWER("Hello World") AS COL

SELECT UPPER("Hello World") AS COL


SELECT TRIM("    Hello World  ") AS COL

SELECT LTRIM("    Hello World  ") AS COL

SELECT RTRIM("    Hello World  ") AS COL


SELECT REVERSE ("HELLO") AS COL


SELECT FORMAT(123456789.80,2) AS COL


SELECT CONCAT('Hello', ' ' , 'SQL') AS COL


SELECT REPLACE ('Hello world' , 'world', 'Dunia') AS COL